namespace ThServer
{
  public enum Directions
  {
    Up,
    Down,
    Left,
    Right,
    Stop
  }
  internal class Player
  {
    public int[] Position { get; private set; }
    public int Score { get; private set; }

    public Directions Direction { get; private set; } = Directions.Stop;

    public Player()
    {
      Position = new int[2];
    }

    public void SetDirection(Directions direction)
    {
      Direction = direction;
    }

    public void SetScore(int score)
    {
      Score = score;
    }

    public void SetPosition(int x, int y)
    {
      Position = [x, y];
    }
  }
}